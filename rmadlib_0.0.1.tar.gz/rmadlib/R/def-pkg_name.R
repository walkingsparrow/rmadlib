
.this.pkg.name <- "rmadlib"
