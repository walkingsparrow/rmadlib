
## Array of overriden functions
## Function name, Package that it belongs to

.localConst.hard.override.funcs <- c("stats::lm" 

                                     ## ,"base::data.frame" # no, actually we are not going to override data.frame
                                 )


