
### method for extracting parts of database object

setMethod("$",
          signature(x = "indb.created"),
          function (x, name)
          {
              
          })
