
### To be finished

### resync indb.created object with its table in database

## setGeneric("resync", def = function (x) standardGeneric("resync"), signature = "x")

## setMethod("resync",
##           signature(x = "indb.created"),
##           function (x)
##           {
          
##           }
##           )
