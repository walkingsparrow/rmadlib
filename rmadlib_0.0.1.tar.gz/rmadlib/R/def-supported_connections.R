
.supported.connections <- c("RODBC", "RPostgreSQL")
