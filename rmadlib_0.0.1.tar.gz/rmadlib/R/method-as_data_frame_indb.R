
## to be finished

## as.data.frame.indb <- function(x, ...) { }

setGeneric("as.data.frame.indb",
           function (x, ...) standardGeneric("as.data.frame.indb"),
           signature = "x")

## setMethod("as.data.frame.indb",
##           signature(x = "data.frame"),
##           function (x, con.id = 1, order.by = NULL)
##           {
              
##           })
